"""
Train Naive Bayes + TF-IDF spam detection model.
Run this once to generate model artifacts.
"""

import pickle
import numpy as np
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
import os

# ── Extended Training Dataset ──────────────────────────────────────────────────
SPAM_EMAILS = [
    "Congratulations! You've won a $1,000,000 lottery prize! Click here to claim now!",
    "FREE iPhone 15 Pro! You've been selected! Claim your prize immediately!",
    "URGENT: Your account will be suspended. Verify your details NOW or lose access forever.",
    "Make $5000 per week working from home! No experience needed! Limited spots!",
    "Hot singles in your area want to meet you tonight! Click here!",
    "Buy cheap Viagra online! No prescription needed! Lowest prices guaranteed!",
    "You are the winner of our weekly sweepstakes! Respond immediately to claim!",
    "Earn easy money! Get rich quick with our proven system! 100% guaranteed!",
    "ATTENTION: Final notice - your computer has a virus! Call 1-800-SCAM-NOW!",
    "Lose 30 pounds in 30 days! Miracle weight loss pill! Order now!",
    "Nigerian prince needs your help to transfer $50 million. You keep 40%!",
    "Your PayPal account has been compromised! Update your password immediately!",
    "FREE credit check! No strings attached! Get your score now!",
    "Best mortgage rates! Refinance your home and save thousands!",
    "WINNER WINNER CHICKEN DINNER! You have been randomly selected!",
    "Click here to unsubscribe from this list you never signed up for",
    "Make money fast with cryptocurrency! Guaranteed 500% returns!",
    "You owe taxes. Pay now or face legal consequences. Call immediately!",
    "Enlarge your body parts with our revolutionary new supplement!",
    "Cheap Rolex watches! Designer brands at 90% off retail price!",
    "You have a pending refund from Amazon. Verify your account details.",
    "Special offer just for you! Act now before this deal expires tonight!",
    "Your email was chosen from millions to receive a special cash prize!",
    "Investment opportunity of a lifetime! Guaranteed returns! Act fast!",
    "Meet beautiful Russian women looking for marriage! Free registration!",
    "Claim your free gift card now! Survey takes only 2 minutes!",
    "ALERT: Suspicious activity detected on your bank account. Verify now!",
    "Pills to cure diabetes, cancer, and arthritis naturally! No side effects!",
    "Work from home and earn $10,000 monthly! No skills required!",
    "You've been pre-approved for a $50,000 loan! Bad credit OK!",
]

HAM_EMAILS = [
    "Hi John, can we reschedule tomorrow's 3pm meeting to Thursday? Works better for me.",
    "Please find the Q3 financial report attached. Let me know if you have questions.",
    "Reminder: Team standup at 10am tomorrow. Agenda includes sprint review and planning.",
    "Thanks for your help with the project last week. Really appreciate your support.",
    "The new software update will be deployed on Friday evening at 6pm.",
    "Could you review my pull request when you get a chance? No rush.",
    "Happy birthday! Hope you have a wonderful day with your family.",
    "The conference schedule has been updated. See the link below for details.",
    "Just a heads up - the office will be closed on Monday for the holiday.",
    "Your order #12345 has been shipped and will arrive by Thursday.",
    "Can you send me the latest version of the presentation slides?",
    "The quarterly review meeting is confirmed for next Tuesday at 2pm.",
    "I've attached the invoice for last month's services. Please process by end of month.",
    "Looking forward to our coffee chat tomorrow at Starbucks on Main Street.",
    "The bug you reported has been fixed in version 2.1.4. Please update when possible.",
    "Just checking in - how is the new project going? Need any resources?",
    "The team lunch is scheduled for Friday noon. We're going to the Italian place.",
    "Please submit your timesheet by 5pm on Friday. HR needs it for payroll.",
    "I've reviewed your proposal and have a few suggestions. Can we discuss Thursday?",
    "Your subscription renewal is coming up on the 15th. No action needed if you want to continue.",
    "Congratulations on your promotion! Well deserved after all your hard work.",
    "The library books you checked out are due back next week.",
    "Your appointment with Dr. Smith is confirmed for Monday at 10:30am.",
    "The monthly newsletter is ready. Here are the highlights from this month.",
    "Could you proofread this document before I send it to the client?",
    "Your package was delivered and left at the front door at 2:34pm.",
    "The project deadline has been extended by one week due to scope changes.",
    "Thank you for attending the webinar. The recording will be available shortly.",
    "Please RSVP for the company picnic by August 15th. Families are welcome.",
    "The IT team will perform maintenance on the servers this weekend.",
]

def train_and_save_model():
    texts = SPAM_EMAILS + HAM_EMAILS
    labels = [1] * len(SPAM_EMAILS) + [0] * len(HAM_EMAILS)

    X_train, X_test, y_train, y_test = train_test_split(
        texts, labels, test_size=0.2, random_state=42, stratify=labels
    )

    # TF-IDF Vectorizer
    vectorizer = TfidfVectorizer(
        max_features=5000,
        ngram_range=(1, 2),
        stop_words='english',
        sublinear_tf=True,
    )
    X_train_tfidf = vectorizer.fit_transform(X_train)
    X_test_tfidf = vectorizer.transform(X_test)

    # Naive Bayes Classifier
    model = MultinomialNB(alpha=0.1)
    model.fit(X_train_tfidf, y_train)

    # Evaluate
    y_pred = model.predict(X_test_tfidf)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"\n✅ Model Training Complete!")
    print(f"   Accuracy: {accuracy:.2%}")
    print(f"\n{classification_report(y_test, y_pred, target_names=['Ham', 'Spam'])}")

    # Save artifacts
    save_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(save_dir, 'model.pkl'), 'wb') as f:
        pickle.dump(model, f)
    with open(os.path.join(save_dir, 'vectorizer.pkl'), 'wb') as f:
        pickle.dump(vectorizer, f)

    print(f"✅ Saved model.pkl and vectorizer.pkl to {save_dir}")
    return accuracy

if __name__ == '__main__':
    train_and_save_model()
