import json
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt

from .models import Prediction
from .predictor import predict


def index(request):
    """Main page - shows classifier form and recent predictions."""
    recent = Prediction.objects.all()[:10]

    stats = {
        'total': Prediction.objects.count(),
        'spam_count': Prediction.objects.filter(result='spam').count(),
        'ham_count': Prediction.objects.filter(result='ham').count(),
    }
    if stats['total'] > 0:
        stats['spam_pct'] = round(stats['spam_count'] / stats['total'] * 100, 1)
        stats['ham_pct'] = round(stats['ham_count'] / stats['total'] * 100, 1)
    else:
        stats['spam_pct'] = 0
        stats['ham_pct'] = 0

    return render(request, 'spam_app/index.html', {
        'recent_predictions': recent,
        'stats': stats,
    })


@csrf_exempt
@require_POST
def classify(request):
    """API endpoint - accepts text, returns classification result."""
    try:
        data = json.loads(request.body)
        text = data.get('text', '').strip()
    except (json.JSONDecodeError, AttributeError):
        text = request.POST.get('text', '').strip()

    if not text:
        return JsonResponse({'error': 'No text provided.'}, status=400)

    if len(text) < 5:
        return JsonResponse({'error': 'Text too short to classify.'}, status=400)

    result = predict(text)

    prediction = Prediction.objects.create(
        text=text,
        result=result['label'],
        confidence=result['confidence'],
        spam_probability=result['spam_probability'],
        ham_probability=result['ham_probability'],
    )

    return JsonResponse({
        'id': prediction.id,
        'label': result['label'],
        'confidence': result['confidence'],
        'spam_probability': result['spam_probability'],
        'ham_probability': result['ham_probability'],
        'confidence_level': prediction.confidence_level,
        'created_at': prediction.created_at.strftime('%b %d, %Y %H:%M'),
    })


def history(request):
    """Returns all stored predictions as JSON."""
    predictions = Prediction.objects.all()[:50]
    data = [
        {
            'id': p.id,
            'text': p.text[:80] + '...' if len(p.text) > 80 else p.text,
            'result': p.result,
            'confidence': p.confidence,
            'confidence_level': p.confidence_level,
            'created_at': p.created_at.strftime('%b %d, %Y %H:%M'),
        }
        for p in predictions
    ]
    return JsonResponse({'predictions': data})
